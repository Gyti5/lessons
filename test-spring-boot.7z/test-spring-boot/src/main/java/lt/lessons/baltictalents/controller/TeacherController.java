package lt.lessons.baltictalents.controller;

import lt.lessons.baltictalents.model.Teacher;
import lt.lessons.baltictalents.repository.TeacherRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;

@Controller
public class TeacherController {

    @Autowired
    TeacherRepository teacherRepository;

    @GetMapping("/addTeacher")
    public String getTeacher(Model model) {
        model.addAttribute("teacher", new Teacher());
        return "addTeacher";
    }


    @RequestMapping(value = "/saveTeacher")
    public String saveItem(Teacher teacher){
        teacherRepository.save(teacher);
        return "done";
    }


}