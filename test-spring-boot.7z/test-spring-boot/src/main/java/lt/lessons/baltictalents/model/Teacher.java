package lt.lessons.baltictalents.model;

import lombok.Getter;
import lombok.Setter;
import lombok.ToString;
import javax.persistence.*;
import java.util.List;


@Entity
@Table(name = "teachers")
@ToString
public class Teacher extends Person{

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Getter
    @Setter
    private Long id;

    @Getter
    @Setter
    private String name;

    @Getter
    @Setter
    private String surname;

    @Getter
    @Setter
    private String title;

    @Getter
    @Setter
    @OneToMany(mappedBy="teacher")
    private List<Lesson> lessons;

}