package lt.lessons.baltictalents.model;

import javax.persistence.*;

import com.fasterxml.jackson.annotation.JsonManagedReference;

import lombok.Getter;
import lombok.Setter;
import lombok.ToString;
import lt.lessons.baltictalents.model.BaseEntity;
import lt.lessons.baltictalents.model.Student;
import lt.lessons.baltictalents.model.Teacher;

@Entity
@Table(name = "lessons")
@ToString
public class Lesson extends BaseEntity {


    @Getter
    @Setter
    private String type;

    @Getter
    @Setter
    private String description;

    @Getter
    @Setter
    private String course;

    @Getter
    @Setter
    @ManyToOne
    @JoinColumn(name="teacher_id", nullable=false)
    private Teacher teacher;

    @Getter
    @Setter
    @ManyToOne
    @JoinColumn(name="student_id", nullable=false)
    private Student student;

}