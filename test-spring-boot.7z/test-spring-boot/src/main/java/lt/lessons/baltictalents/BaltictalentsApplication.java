package lt.lessons.baltictalents;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class BaltictalentsApplication {

	public static void main(String[] args) {
		SpringApplication.run(BaltictalentsApplication.class, args);
	}

}

