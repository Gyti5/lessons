package lt.lessons.baltictalents.repository;

import lt.lessons.baltictalents.model.BaseEntity;
import lt.lessons.baltictalents.model.Lesson;
import org.springframework.data.repository.CrudRepository;
import org.springframework.stereotype.Repository;

import java.util.List;

@Repository
public interface LessonRepository extends CrudRepository<BaseEntity, Long> {
    Lesson findByCourse(String Course);
    Lesson findByType(String Type);
    List<BaseEntity> findAll();
}
