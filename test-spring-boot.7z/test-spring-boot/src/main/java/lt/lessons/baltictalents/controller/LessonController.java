package lt.lessons.baltictalents.controller;

import lt.lessons.baltictalents.model.Lesson;
import lt.lessons.baltictalents.repository.LessonRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;

@Controller
public class LessonController {

    @Autowired
    LessonRepository lessonRepository;

    @GetMapping("/addLesson")
    public String getLesson(Model model) {
        model.addAttribute("lesson", new Lesson());
        return "addLesson";
    }


    @RequestMapping(value = "/saveLesson")
    public String saveItem(Lesson lesson){
        lessonRepository.save(lesson);
        return "done";
    }


}