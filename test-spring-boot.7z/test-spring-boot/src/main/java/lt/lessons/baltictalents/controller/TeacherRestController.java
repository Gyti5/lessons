package lt.lessons.baltictalents.controller;

import lombok.val;
import lt.lessons.baltictalents.model.Person;
import lt.lessons.baltictalents.repository.TeacherRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

@RestController
@RequestMapping("/api")
public class TeacherRestController {
    @Autowired
    TeacherRepository teacherRepository;

    @RequestMapping(value ="/teacher/{teacherId}", method= RequestMethod.GET)
    public Person getLesson(@PathVariable("teacherId") long teacherId){
        val teacher = teacherRepository.findById(teacherId);

        return teacher.get();
    }



}